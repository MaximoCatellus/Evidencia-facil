import React, { useState, useEffect } from "react";
import {
  Clock,
  Table as TableIcon,
  ArrowRightLeft,
  ShieldQuestion,
  AlertCircle,
  FileSearch,
  Sparkles,
  CheckCircle2,
  RefreshCw,
  Scale,
  GitFork,
  Database
} from "lucide-react";
import { Header } from "./components/Header";
import { UploadZone } from "./components/UploadZone";
import { ExecutiveSummary } from "./components/ExecutiveSummary";
import { TimelineView } from "./components/TimelineView";
import { EvidenceMatrix } from "./components/EvidenceMatrix";
import { ContradictionsView } from "./components/ContradictionsView";
import { EvidentiaryGapsView } from "./components/EvidentiaryGapsView";
import { BayesianGraphView } from "./components/BayesianGraphView";
import { ArgumentGraphView } from "./components/ArgumentGraphView";
import { ExportBar } from "./components/ExportBar";
import { DocumentModal } from "./components/DocumentModal";
import { PrintReport } from "./components/PrintReport";
import { UploadedFile, AnalysisResult, TimelineEvent } from "./types/ediscovery";
import { SAMPLE_CASES } from "./data/sampleCases";
import { sortAndNormalizeChronology, detectEvidentiaryGaps } from "./lib/chronologyEngine";

export default function App() {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [caseContext, setCaseContext] = useState<string>("");
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [activeCaseId, setActiveCaseId] = useState<string | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<
    "timeline" | "matrix" | "contradictions" | "gaps" | "bayesian" | "arguments"
  >("timeline");
  const [selectedEventModal, setSelectedEventModal] = useState<TimelineEvent | null>(null);
  const [warningNotice, setWarningNotice] = useState<string | null>(null);
  const [isRestoredFromLocal, setIsRestoredFromLocal] = useState(false);

  // Restore analysis from localStorage on initial page load (Zero DB, Zero API cost on reload)
  useEffect(() => {
    try {
      const cachedAnalysis = localStorage.getItem("ediscovery_current_analysis");
      const cachedFiles = localStorage.getItem("ediscovery_uploaded_files");
      const cachedContext = localStorage.getItem("ediscovery_case_context");

      if (cachedAnalysis) {
        const parsed = JSON.parse(cachedAnalysis);
        setAnalysis(parsed);
        setIsRestoredFromLocal(true);
        if (cachedFiles) {
          setFiles(JSON.parse(cachedFiles));
        }
        if (cachedContext) {
          setCaseContext(cachedContext);
        }
      }
    } catch (e) {
      console.warn("No fue posible restaurar desde localStorage:", e);
    }
  }, []);

  // Load a pre-configured sample case
  const handleLoadSample = (caseId: string) => {
    const sample = SAMPLE_CASES.find((c) => c.id === caseId);
    if (!sample) return;

    setFiles(sample.files);
    setCaseContext(sample.suggestedContext);
    setAnalysis(sample.precomputedResult);
    setActiveCaseId(caseId);
    setError(null);
    setWarningNotice(null);
    setIsRestoredFromLocal(false);
    setActiveTab("timeline");
  };

  // Start fresh analysis (clears localStorage)
  const handleNewAnalysis = () => {
    setFiles([]);
    setCaseContext("");
    setAnalysis(null);
    setActiveCaseId(undefined);
    setError(null);
    setWarningNotice(null);
    setIsRestoredFromLocal(false);
    try {
      localStorage.removeItem("ediscovery_current_analysis");
      localStorage.removeItem("ediscovery_uploaded_files");
      localStorage.removeItem("ediscovery_case_context");
    } catch {}
  };

  // Handle file additions or deletions
  const handleFilesChange = (newFiles: UploadedFile[]) => {
    setFiles(newFiles);
    setAnalysis(null);
    setActiveCaseId(undefined);
    setError(null);
    setWarningNotice(null);
    setIsRestoredFromLocal(false);
    if (newFiles.length === 0) {
      setCaseContext("");
    }
  };

  // Run analysis via server API endpoint
  const handleAnalyze = async () => {
    if (files.length === 0) return;

    setIsLoading(true);
    setLoadingStep("Extrayendo texto y analizando soportes probatorios con OCR...");
    setError(null);
    setWarningNotice(null);
    setAnalysis(null);

    try {
      const payloadFiles = files.map((f) => ({
        name: f.name,
        type: f.type,
        base64: f.base64,
        textContent: f.textContent,
        size: f.size
      }));

      setLoadingStep("Gemini AI realizando lectura OCR y estructuración procesal...");

      const isSampleFileSet = files.some((f) => f.id.startsWith("cf-") || f.id.startsWith("lab-"));
      let effectiveContext = caseContext.trim();
      if (!isSampleFileSet && (effectiveContext.toLowerCase().includes("los robles") || effectiveContext.toLowerCase().includes("constructora delta"))) {
        effectiveContext = "";
      }

      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          files: payloadFiles,
          caseContext: effectiveContext
        })
      });

      const responseText = await res.text();
      let data: any = null;

      try {
        data = JSON.parse(responseText);
      } catch {
        if (
          res.status === 504 ||
          responseText.includes("TIMEOUT") ||
          responseText.includes("FUNCTION_INVOCATION") ||
          responseText.includes("An error occurred")
        ) {
          throw new Error(
            "El servidor de Vercel agotó el tiempo de espera (Timeout de 10s en plan gratuito). Los servidores de Google Gemini tardaron en responder debido a la alta demanda o al peso de los archivos. Prueba enviando los archivos de 1 en 1 o pulsando 'Reintentar Ahora'."
          );
        }
        throw new Error(
          `Respuesta del servidor (${res.status}): ${responseText.slice(0, 160)}`
        );
      }

      if (!res.ok || !data.success) {
        throw new Error(data?.error || "Error al procesar el expediente probatorio.");
      }

      setLoadingStep("Estructurando cronología judicial y calculando vacíos probatorios...");

      // ALGORITMO DETERMINISTA EN CLIENTE (lib/chronologyEngine.ts):
      // 1. Ordenación cronológica exacta en JavaScript nativo
      const sortedEvents = sortAndNormalizeChronology(data.data.cronologia || []);

      // 2. Detección automática de vacíos probatorios (silencio > 30 días) sin llamadas a la API
      const detectedGaps = detectEvidentiaryGaps(sortedEvents, 30);

      const mergedGaps = [...(data.data.vacios_probatorios || [])];
      detectedGaps.forEach((dg: any) => {
        if (!mergedGaps.some((g: any) => g.hecho_o_periodo_afectado?.includes(dg.periodoAfectado))) {
          mergedGaps.push({
            id: dg.id,
            descripcion: `Silencio procesal prolongado (${dg.diasInactividad} días sin comunicaciones registradas)`,
            hecho_o_periodo_afectado: dg.periodoAfectado,
            riesgo_procesal: dg.riesgoProcesal,
            diligencia_o_prueba_sugerida: dg.diligenciaSugerida,
            prioridad: dg.nivelRiesgo === "Crítico" ? "Alta" : dg.nivelRiesgo === "Alto" ? "Media" : "Baja"
          });
        }
      });

      const enrichedAnalysis: AnalysisResult = {
        ...data.data,
        cronologia: sortedEvents,
        vacios_probatorios: mergedGaps
      };

      setAnalysis(enrichedAnalysis);
      setIsRestoredFromLocal(false);

      // Persistencia local en el navegador (Cero DB, Cero Coste de Hosting)
      try {
        localStorage.setItem("ediscovery_current_analysis", JSON.stringify(enrichedAnalysis));
        localStorage.setItem("ediscovery_uploaded_files", JSON.stringify(payloadFiles));
        localStorage.setItem("ediscovery_case_context", effectiveContext);
      } catch (storageErr) {
        console.warn("No fue posible almacenar en localStorage:", storageErr);
      }

      if (data.warning) {
        setWarningNotice(data.warning);
      }
      setActiveCaseId(undefined);
      setActiveTab("timeline");
    } catch (err: any) {
      console.error("Error analizando expediente:", err);
      setError(
        err.message || "Ocurrió un error inesperado al comunicarse con el servidor de análisis."
      );
    } finally {
      setIsLoading(false);
      setLoadingStep("");
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 font-sans antialiased flex flex-col">
      {/* Navbar & Ethics Banner */}
      <Header
        onLoadSample={handleLoadSample}
        activeCaseId={activeCaseId}
        hasAnalysis={Boolean(analysis)}
        onNewAnalysis={handleNewAnalysis}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 print:p-0">
        {/* Error notification if any */}
        {error && (
          <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block mb-0.5">Aviso del Sistema Procesal:</span>
                <p>
                  {error.includes("503") || error.includes("high demand")
                    ? "Los servidores de IA de Google experimentaron un pico de alta demanda temporal (Error 503). Esto suele solucionarse de inmediato. Haz clic en 'Reintentar Ahora'."
                    : error}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
              <button
                type="button"
                onClick={handleAnalyze}
                className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-medium rounded text-xs transition-colors inline-flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Reintentar Ahora
              </button>
              <button
                type="button"
                onClick={() => setError(null)}
                className="px-2.5 py-1.5 text-rose-700 hover:text-rose-900 font-medium"
              >
                Descartar
              </button>
            </div>
          </div>
        )}

        {/* Upload & Setup Zone */}
        <div className="print:hidden">
          <UploadZone
            files={files}
            onFilesChange={handleFilesChange}
            caseContext={caseContext}
            onCaseContextChange={setCaseContext}
            onAnalyze={handleAnalyze}
            isLoading={isLoading}
            onLoadSample={handleLoadSample}
            activeCaseId={activeCaseId}
            onClearCase={handleNewAnalysis}
          />
        </div>

        {/* Loading Progress State */}
        {isLoading && (
          <div className="bg-white rounded-xl border border-blue-200 shadow-sm p-8 text-center my-6 animate-pulse">
            <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-3">
              <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 mb-1">
              Procesando Expediente de E-Discovery
            </h3>
            <p className="text-xs text-blue-700 font-medium font-mono">
              {loadingStep || "Analizando documentos con inteligencia artificial..."}
            </p>
            <p className="text-[11px] text-slate-400 mt-2">
              Extrayendo fechas, personas, citas literales y trazabilidad documental 1:1...
            </p>
          </div>
        )}

        {/* Warning notice with retry button if applicable */}
        {warningNotice && !isLoading && (
          <div className="mb-6 p-3.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs print:hidden">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>{warningNotice}</span>
            </div>
            <button
              type="button"
              onClick={handleAnalyze}
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-medium rounded text-xs shrink-0 transition-colors inline-flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Reintentar con Gemini AI
            </button>
          </div>
        )}

        {/* Results Dashboard */}
        {analysis && !isLoading && (
          <div className="space-y-6">
            {/* Executive Summary */}
            <div className="print:hidden">
              <ExecutiveSummary
                summary={analysis.resumen_caso}
                metadata={analysis.metadata_analisis}
                recommendations={analysis.recomendaciones_legales}
              />
            </div>

            {/* Export Toolbar */}
            <ExportBar analysis={analysis} />

            {/* Dashboard Navigation Tabs */}
            <div className="border-b border-slate-200 flex items-center gap-1 sm:gap-2 overflow-x-auto pb-px print:hidden">
              <button
                type="button"
                onClick={() => setActiveTab("timeline")}
                className={`flex items-center gap-2 py-3 px-4 text-xs font-semibold border-b-2 transition-all whitespace-nowrap ${
                  activeTab === "timeline"
                    ? "border-slate-900 text-slate-900"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <Clock className="w-4 h-4" />
                <span>Línea de Tiempo ({analysis.cronologia.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab("matrix")}
                className={`flex items-center gap-2 py-3 px-4 text-xs font-semibold border-b-2 transition-all whitespace-nowrap ${
                  activeTab === "matrix"
                    ? "border-slate-900 text-slate-900"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <TableIcon className="w-4 h-4" />
                <span>Matriz de Pruebas</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab("contradictions")}
                className={`flex items-center gap-2 py-3 px-4 text-xs font-semibold border-b-2 transition-all whitespace-nowrap ${
                  activeTab === "contradictions"
                    ? "border-rose-600 text-rose-700"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <ArrowRightLeft className="w-4 h-4" />
                <span>Contradicciones ({analysis.contradicciones.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab("gaps")}
                className={`flex items-center gap-2 py-3 px-4 text-xs font-semibold border-b-2 transition-all whitespace-nowrap ${
                  activeTab === "gaps"
                    ? "border-amber-600 text-amber-800"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <ShieldQuestion className="w-4 h-4" />
                <span>Vacíos Probatorios ({analysis.vacios_probatorios.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab("bayesian")}
                className={`flex items-center gap-2 py-3 px-4 text-xs font-semibold border-b-2 transition-all whitespace-nowrap ${
                  activeTab === "bayesian"
                    ? "border-blue-600 text-blue-700 bg-blue-50/40"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <Scale className="w-4 h-4 text-blue-600" />
                <span>
                  Evaluación Bayesiana {analysis.red_bayesiana?.evidencias ? `(${analysis.red_bayesiana.evidencias.length})` : ""}
                </span>
                <span className="text-[10px] bg-blue-100 text-blue-800 font-mono px-1.5 py-0.2 rounded-full">
                  P(H|E)
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab("arguments")}
                className={`flex items-center gap-2 py-3 px-4 text-xs font-semibold border-b-2 transition-all whitespace-nowrap ${
                  activeTab === "arguments"
                    ? "border-indigo-600 text-indigo-700 bg-indigo-50/40"
                    : "border-transparent text-slate-500 hover:text-slate-800"
                }`}
              >
                <GitFork className="w-4 h-4 text-indigo-600" />
                <span>Grafo Argumental</span>
                <span className="text-[10px] bg-indigo-100 text-indigo-800 font-mono px-1.5 py-0.2 rounded-full">
                  Toulmin
                </span>
              </button>
            </div>

            {/* Restored from local cache banner */}
            {isRestoredFromLocal && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-lg text-xs flex items-center justify-between gap-2 shadow-xs print:hidden">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>
                    <strong>Expediente cargado desde localStorage:</strong> Se recuperó el análisis previo de la memoria local sin consumir tokens ni invocar a la API de Gemini.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsRestoredFromLocal(false)}
                  className="text-emerald-700 hover:text-emerald-900 font-semibold text-[11px]"
                >
                  Entendido
                </button>
              </div>
            )}

            {/* Tab Views */}
            <div className="print:hidden">
              {activeTab === "timeline" && (
                <TimelineView
                  events={analysis.cronologia}
                  onSelectEvent={(ev) => setSelectedEventModal(ev)}
                />
              )}

              {activeTab === "matrix" && (
                <EvidenceMatrix
                  events={analysis.cronologia}
                  onSelectEvent={(ev) => setSelectedEventModal(ev)}
                />
              )}

              {activeTab === "contradictions" && (
                <ContradictionsView contradictions={analysis.contradicciones} />
              )}

              {activeTab === "gaps" && (
                <EvidentiaryGapsView gaps={analysis.vacios_probatorios} />
              )}

              {activeTab === "bayesian" && (
                <BayesianGraphView network={analysis.red_bayesiana} />
              )}

              {activeTab === "arguments" && (
                <ArgumentGraphView analysis={analysis} />
              )}
            </div>

            {/* Printable official legal layout */}
            <PrintReport analysis={analysis} />
          </div>
        )}

        {/* Source Citation & Document Inspection Modal */}
        {selectedEventModal && (
          <DocumentModal
            event={selectedEventModal}
            uploadedFiles={files}
            onClose={() => setSelectedEventModal(null)}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 mt-12 print:hidden text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">EvidenciaFácil</span>
            <span aria-hidden="true">·</span>
            <span>Democratizador de E-Discovery para Ciudadanos y Litigantes</span>
          </div>

          <div className="text-center sm:text-right text-[11px] text-slate-400">
            Procesamiento multimodal con Gemini API · Trazabilidad 1:1 · Cumplimiento de Admisibilidad Digital
          </div>
        </div>
      </footer>
    </div>
  );
}
